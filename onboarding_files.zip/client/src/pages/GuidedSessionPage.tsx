import { useState, useEffect, useCallback, useRef } from "react";
import { useRoute, useLocation } from "wouter";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { useGame } from "@/context/GameContext";
import { useTheme } from "@/context/ThemeContext";
import { useLanguage } from "@/context/LanguageStageContext";
import { apiRequest } from "@/lib/queryClient";
import { DayCloseOverlay } from "@/components/game/DayCloseOverlay";
import { Day5ExpansionOverlay } from "@/components/game/Day5ExpansionOverlay";
import { Wind, Heart, Droplets, Brain, X } from "lucide-react";
import { LightMovementEngine } from "@/components/game/LightMovementEngine";
import { CardioSessionEngine } from "@/components/game/CardioSessionEngine";

type SessionId = "calm-breathing" | "light-movement" | "hydration-check" | "quick-reflection" | "focus-block" | "plan-tomorrow";

interface SessionConfig {
  id: SessionId;
  title: string;
  stat: string;
  durationSeconds: number;
  icon: typeof Wind;
  type: "breathing" | "prompts" | "instant" | "timer";
}

const SESSIONS: Record<SessionId, SessionConfig> = {
  "calm-breathing": {
    id: "calm-breathing",
    title: "2-Minute Reset",
    stat: "sense",
    durationSeconds: 126,
    icon: Wind,
    type: "breathing",
  },
  "light-movement": {
    id: "light-movement",
    title: "Light Movement",
    stat: "agility",
    durationSeconds: 150,
    icon: Heart,
    type: "prompts",
  },
  "hydration-check": {
    id: "hydration-check",
    title: "Hydration Check",
    stat: "vitality",
    durationSeconds: 0,
    icon: Droplets,
    type: "instant",
  },
  "quick-reflection": {
    id: "quick-reflection",
    title: "Quick Reflection",
    stat: "sense",
    durationSeconds: 60,
    icon: Brain,
    type: "timer",
  },
  "focus-block": {
    id: "focus-block",
    title: "Focus Block",
    stat: "sense",
    durationSeconds: 180,
    icon: Brain,
    type: "timer",
  },
  "plan-tomorrow": {
    id: "plan-tomorrow",
    title: "Plan Tomorrow",
    stat: "vitality",
    durationSeconds: 0,
    icon: Brain,
    type: "instant",
  },
};

const INHALE_URL = "/audio/inhale.mp3";
const HOLD_URL = "/audio/hold.mp3";
const EXHALE_URL = "/audio/exhale.mp3";

const BREATHING_PHASES = [
  { label: "Inhale", duration: 4000 },
  { label: "Hold", duration: 4000 },
  { label: "Exhale", duration: 6000 },
];

const CYCLE_MS = BREATHING_PHASES.reduce((s, p) => s + p.duration, 0); // 14000ms

const MOVEMENT_PROMPTS = [
  { text: "Roll your shoulders slowly, forward and back.", at: 0 },
  { text: "Stretch your arms above your head. Hold.", at: 30 },
  { text: "Gently twist your torso left, then right.", at: 60 },
  { text: "Touch your toes or reach as far as you can.", at: 90 },
  { text: "Shake out your hands and arms. Release tension.", at: 120 },
];

const STAT_COLORS: Record<string, string> = {
  strength: "#ef4444",
  agility: "#22c55e",
  sense: "#3b82f6",
  vitality: "#f59e0b",
};

function createPadOscillator(
  ctx: AudioContext,
  freq: number,
  detuneCents: number,
  gainValue: number,
  destination: AudioNode
) {
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(freq, ctx.currentTime);
  osc.detune.setValueAtTime(detuneCents, ctx.currentTime);
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(gainValue, ctx.currentTime);
  osc.connect(gain).connect(destination);
  osc.start();
  return osc;
}

function useBreathingAudio(active: boolean) {
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);
  const lfoRef = useRef<OscillatorNode | null>(null);
  useEffect(() => {
    if (!active) return;

    try {
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0, ctx.currentTime);
      masterGain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 3);

      const lpFilter = ctx.createBiquadFilter();
      lpFilter.type = "lowpass";
      lpFilter.frequency.setValueAtTime(600, ctx.currentTime);
      lpFilter.Q.setValueAtTime(0.7, ctx.currentTime);

      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(0.03, ctx.currentTime);
      const lfo = ctx.createOscillator();
      lfo.type = "sine";
      lfo.frequency.setValueAtTime(0.15, ctx.currentTime);
      lfo.connect(lfoGain).connect(masterGain.gain);
      lfo.start();
      lfoRef.current = lfo;

      lpFilter.connect(masterGain).connect(ctx.destination);

      const oscs: OscillatorNode[] = [];
      oscs.push(createPadOscillator(ctx, 130.81, -4, 0.35, lpFilter));
      oscs.push(createPadOscillator(ctx, 130.81, 4, 0.35, lpFilter));
      oscs.push(createPadOscillator(ctx, 196.00, -3, 0.2, lpFilter));
      oscs.push(createPadOscillator(ctx, 196.00, 3, 0.2, lpFilter));
      oscs.push(createPadOscillator(ctx, 261.63, -5, 0.12, lpFilter));
      oscs.push(createPadOscillator(ctx, 261.63, 5, 0.12, lpFilter));
      oscs.push(createPadOscillator(ctx, 329.63, 0, 0.06, lpFilter));
      oscillatorsRef.current = oscs;
    } catch {}

    return () => {
      try {
        oscillatorsRef.current.forEach(o => { try { o.stop(); } catch {} });
        if (lfoRef.current) try { lfoRef.current.stop(); } catch {}
        audioCtxRef.current?.close();
      } catch {}
      oscillatorsRef.current = [];
      lfoRef.current = null;
      audioCtxRef.current = null;
    };
  }, [active]);
}

// ─── Voice clip phase durations & order ──────────────────────────────────────
const VOICE_DURATIONS: Record<"Inhale" | "Hold" | "Exhale", number> = {
  Inhale: 4000,
  Hold:   4000,
  Exhale: 6000,
};
const VOICE_NEXT: Record<"Inhale" | "Hold" | "Exhale", "Inhale" | "Hold" | "Exhale"> = {
  Inhale: "Hold",
  Hold:   "Exhale",
  Exhale: "Inhale",
};

// ─── Calm background music (pentatonic, Web Audio) ───────────────────────────
const CALM_NOTES = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25]; // C D E G A C (pentatonic)

function useCalmMusic(active: boolean) {
  const ctxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!active) return;

    let closed = false;

    const playNote = (ctx: AudioContext, dest: GainNode) => {
      if (closed) return;
      const freq = CALM_NOTES[Math.floor(Math.random() * CALM_NOTES.length)];
      // Occasionally play the note an octave up for shimmer
      const f = Math.random() > 0.7 ? freq * 2 : freq;

      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.setValueAtTime(f, ctx.currentTime);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0, ctx.currentTime);
      g.gain.linearRampToValueAtTime(0.055, ctx.currentTime + 1.2);
      g.gain.linearRampToValueAtTime(0.03, ctx.currentTime + 3.5);
      g.gain.linearRampToValueAtTime(0, ctx.currentTime + 5.5);

      osc.connect(g);
      g.connect(dest);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 6);
    };

    const schedule = (ctx: AudioContext, dest: GainNode) => {
      if (closed) return;
      playNote(ctx, dest);
      const delay = 2800 + Math.random() * 3200;
      timerRef.current = setTimeout(() => schedule(ctx, dest), delay);
    };

    try {
      const ctx = new AudioContext();
      ctxRef.current = ctx;

      const master = ctx.createGain();
      master.gain.setValueAtTime(0, ctx.currentTime);
      master.gain.linearRampToValueAtTime(1, ctx.currentTime + 6);
      master.connect(ctx.destination);

      // Start first note after 4s (let ambient pad settle first)
      timerRef.current = setTimeout(() => schedule(ctx, master), 4000);
    } catch {}

    return () => {
      closed = true;
      if (timerRef.current) clearTimeout(timerRef.current);
      try { ctxRef.current?.close(); } catch {}
      ctxRef.current = null;
    };
  }, [active]);
}


function BreathingSession({ accentColor }: { accentColor: string }) {
  const [phase, setPhase] = useState<"Inhale" | "Hold" | "Exhale">("Inhale");

  useBreathingAudio(true);
  useCalmMusic(true);

  useEffect(() => {
    let alive = true;

    // ── Pre-load voice clips with HTMLAudioElement (most reliable cross-browser) ──
    const clips: Record<"Inhale" | "Hold" | "Exhale", HTMLAudioElement> = {
      Inhale: new Audio(INHALE_URL),
      Hold:   new Audio(HOLD_URL),
      Exhale: new Audio(EXHALE_URL),
    };
    Object.values(clips).forEach(a => { a.volume = 0.85; a.preload = "auto"; a.load(); });

    const playClip = (p: "Inhale" | "Hold" | "Exhale") => {
      // Stop any currently playing clip first
      Object.values(clips).forEach(a => { try { a.pause(); a.currentTime = 0; } catch {} });
      clips[p].play().catch(() => {}); // silently ignore autoplay blocks
    };

    // ── Phase cycling — drives both the visual label and audio cues ──────────
    let curPhase: "Inhale" | "Hold" | "Exhale" = "Inhale";
    let phaseStart = performance.now();
    setPhase("Inhale");
    // Play first cue immediately
    playClip("Inhale");

    const tickId = setInterval(() => {
      if (!alive) return;
      if (performance.now() - phaseStart >= VOICE_DURATIONS[curPhase]) {
        curPhase = VOICE_NEXT[curPhase];
        phaseStart = performance.now();
        setPhase(curPhase);
        playClip(curPhase);
      }
    }, 100);

    return () => {
      alive = false;
      clearInterval(tickId);
      Object.values(clips).forEach(a => { try { a.pause(); a.src = ""; } catch {} });
    };
  }, []);

  // Circle: small → large on inhale, stays large on hold, large → small on exhale
  const scale = phase === "Inhale" ? 1.0 : phase === "Hold" ? 1.0 : 0.5;
  const transitionDuration =
    phase === "Inhale" ? `${VOICE_DURATIONS.Inhale / 1000}s`
    : phase === "Hold"   ? "0.2s"
    : `${VOICE_DURATIONS.Exhale / 1000}s`;

  // Duration label shown below phase name
  const phaseHint =
    phase === "Inhale" ? `${VOICE_DURATIONS.Inhale / 1000}s`
    : phase === "Hold"   ? `${VOICE_DURATIONS.Hold / 1000}s`
    : `${VOICE_DURATIONS.Exhale / 1000}s`;

  return (
    <div className="flex flex-col items-center gap-8">
      <div
        className="w-32 h-32 rounded-full"
        style={{
          transform: `scale(${scale})`,
          transition: `transform ${transitionDuration} ease-in-out`,
          background: `radial-gradient(circle, ${accentColor}30 0%, ${accentColor}10 60%, transparent 100%)`,
          border: `2px solid ${accentColor}40`,
          boxShadow: phase === "Hold"
            ? `0 0 40px ${accentColor}30`
            : `0 0 20px ${accentColor}15`,
        }}
      />
      <div className="flex flex-col items-center gap-1">
        <p
          data-testid="breathing-phase-label"
          className="text-xl font-display font-medium tracking-wider"
          style={{ color: `${accentColor}cc` }}
        >
          {phase}
        </p>
        <p className="text-xs" style={{ color: `${accentColor}55` }}>
          {phaseHint}
        </p>
      </div>
      <p className="text-[10px] tracking-wide" style={{ color: "rgba(255,255,255,0.25)" }}>
        Voice guided · Ambient audio
      </p>
    </div>
  );
}

function PromptSession({ elapsed, accentColor }: { elapsed: number; accentColor: string }) {
  let currentPrompt = MOVEMENT_PROMPTS[0];
  for (const p of MOVEMENT_PROMPTS) {
    if (elapsed >= p.at) currentPrompt = p;
  }

  return (
    <div className="flex flex-col items-center gap-6 px-4">
      <div
        className="w-16 h-16 rounded-full flex items-center justify-center"
        style={{ backgroundColor: `${accentColor}15` }}
      >
        <Heart size={28} style={{ color: accentColor }} />
      </div>
      <p
        data-testid="movement-prompt"
        className="text-center text-base leading-relaxed max-w-xs"
        style={{ color: "rgba(255,255,255,0.85)" }}
      >
        {currentPrompt.text}
      </p>
    </div>
  );
}

const INSTANT_CONTENT: Record<string, { icon: typeof Wind; heading: string; body: string; button: string }> = {
  "hydration-check": {
    icon: Droplets,
    heading: "Drink a full glass of water.",
    body: "Take your time. Hydration supports everything.",
    button: "Done",
  },
  "plan-tomorrow": {
    icon: Brain,
    heading: "Choose a time for tomorrow's practice.",
    body: "Structure protects consistency. Pick a moment that works for you.",
    button: "I've chosen a time",
  },
};

function InstantSession({ sessionId, accentColor, onDone }: { sessionId: string; accentColor: string; onDone: () => void }) {
  const content = INSTANT_CONTENT[sessionId] || INSTANT_CONTENT["hydration-check"];
  const Icon = content.icon;

  return (
    <div className="flex flex-col items-center gap-8 px-4">
      <div
        className="w-16 h-16 rounded-full flex items-center justify-center"
        style={{ backgroundColor: `${accentColor}15` }}
      >
        <Icon size={28} style={{ color: accentColor }} />
      </div>
      <div className="text-center space-y-3">
        <p className="text-base leading-relaxed" style={{ color: "rgba(255,255,255,0.85)" }}>
          {content.heading}
        </p>
        <p className="text-sm" style={{ color: "rgba(255,255,255,0.45)" }}>
          {content.body}
        </p>
      </div>
      <button
        data-testid="button-instant-done"
        onClick={onDone}
        className="mt-4 px-10 py-3 rounded-xl font-display text-sm uppercase tracking-[0.12em] transition-all active:scale-[0.97]"
        style={{
          backgroundColor: `${accentColor}15`,
          border: `1px solid ${accentColor}25`,
          color: `${accentColor}dd`,
        }}
      >
        {content.button}
      </button>
    </div>
  );
}

const TIMER_CONTENT: Record<string, { heading: string; body: string }> = {
  "quick-reflection": {
    heading: "Close your eyes. Reflect on one thing you're grateful for.",
    body: "Let thoughts settle. No need to force anything.",
  },
  "focus-block": {
    heading: "Focus on one thing. Let everything else go.",
    body: "3 minutes of uninterrupted attention. No switching.",
  },
};

function TimerSession({ sessionId, elapsed, total, accentColor }: { sessionId: string; elapsed: number; total: number; accentColor: string }) {
  const remaining = Math.max(0, total - elapsed);
  const mins = Math.floor(remaining / 60);
  const secs = remaining % 60;
  const content = TIMER_CONTENT[sessionId] || TIMER_CONTENT["quick-reflection"];

  return (
    <div className="flex flex-col items-center gap-8 px-4">
      <div
        className="w-16 h-16 rounded-full flex items-center justify-center"
        style={{ backgroundColor: `${accentColor}15` }}
      >
        <Brain size={28} style={{ color: accentColor }} />
      </div>
      <div className="text-center space-y-3">
        <p className="text-base leading-relaxed" style={{ color: "rgba(255,255,255,0.85)" }}>
          {content.heading}
        </p>
        <p className="text-sm" style={{ color: "rgba(255,255,255,0.45)" }}>
          {content.body}
        </p>
      </div>
      <p
        data-testid="reflection-timer"
        className="text-3xl font-display font-light tracking-wider"
        style={{ color: `${accentColor}99` }}
      >
        {mins}:{secs.toString().padStart(2, "0")}
      </p>
    </div>
  );
}

/* ─── Completion beep (triple ascending tone, same pattern as training engine) */
function playSessionCompleteBeep() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    [0, 0.14, 0.28].forEach((delay, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = [660, 880, 1100][i];
      osc.type = "sine";
      gain.gain.setValueAtTime(0.28, ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.25);
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + 0.25);
    });
    setTimeout(() => { try { ctx.close(); } catch {} }, 1200);
  } catch {}
}

export default function GuidedSessionPage() {
  const [, params] = useRoute("/guided-session/:sessionId");
  const [, setLocation] = useLocation();
  const { player } = useGame();
  const { backgroundTheme } = useTheme();
  const { t } = useLanguage();
  const queryClient = useQueryClient();

  const sessionId = (params?.sessionId || "calm-breathing") as SessionId;
  const session = SESSIONS[sessionId];

  const [state, setState] = useState<"countdown" | "active" | "completing" | "done">(
    session?.type === "breathing" ? "countdown" : "active"
  );
  const [countdown, setCountdown] = useState(5);
  const [elapsed, setElapsed] = useState(0);
  const [showDayClose, setShowDayClose] = useState(false);
  const [showDay5Expansion, setShowDay5Expansion] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const intervalRef        = useRef<ReturnType<typeof setInterval> | null>(null);
  const completeTimeoutRef = useRef<ReturnType<typeof setTimeout>  | null>(null);

  // Unlock HTMLAudioElement playback immediately on page mount for breathing sessions.
  // The browser requires at least one .play() that traces back to a user gesture.
  // We do this here while the mount is still close to the "Start" button click.
  useEffect(() => {
    if (session?.type !== "breathing") return;
    const unlock = new Audio(INHALE_URL);
    unlock.volume = 0;
    unlock.play()
      .then(() => { unlock.pause(); unlock.src = ""; })
      .catch(() => { unlock.src = ""; });
  }, []);

  const { data: homeData } = useQuery<{ onboardingDay: number; hasCompletedHabitToday: boolean; completedToday: number }>({
    queryKey: ["home", player?.id],
    queryFn: async () => {
      if (!player?.id) throw new Error("No player");
      const res = await fetch(`/api/player/${player.id}/home`);
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!player?.id,
    staleTime: 30000,
  });

  /* Advance out of "completing" — only called on confirmed server success */
  const advanceFromCompleting = useCallback(() => {
    if (completeTimeoutRef.current) {
      clearTimeout(completeTimeoutRef.current);
      completeTimeoutRef.current = null;
    }
    queryClient.invalidateQueries({ queryKey: ["home"] });
    queryClient.invalidateQueries({ queryKey: ["/api/player"] });

    // For onboarding sessions, signal the home page to show the completion screen
    const ONBOARDING_SESSION_TO_DAY: Record<string, number> = {
      "calm-breathing": 1, "light-movement": 2, "hydration-check": 3,
      "focus-block": 4, "plan-tomorrow": 5,
    };
    const completedOnboardingDay = ONBOARDING_SESSION_TO_DAY[sessionId];
    if (completedOnboardingDay) {
      sessionStorage.setItem("ascend_just_completed_day", String(completedOnboardingDay));
      setLocation("/");
      return;
    }

    // Non-onboarding sessions: standard behavior
    const isFirstCompletionToday = !homeData?.hasCompletedHabitToday;
    if (isFirstCompletionToday) {
      setShowDayClose(true);
    } else {
      setState("done");
    }
  }, [homeData, queryClient, sessionId, setLocation]);

  const completeMutation = useMutation({
    mutationFn: async () => {
      if (!player?.id) throw new Error("No player");
      const res = await apiRequest("POST", `/api/player/${player.id}/complete-guided-session`, {
        sessionId: session.id,
        stat: session.stat,
        durationMinutes: Math.max(1, Math.ceil(session.durationSeconds / 60)),
      });
      return res.json();
    },
    onSuccess: async () => {
      // Refetch immediately so the completed state is ready when user returns home
      await Promise.allSettled([
        queryClient.refetchQueries({ queryKey: ["home", player?.id] }),
        queryClient.refetchQueries({ queryKey: ["/api/player", player?.id] }),
      ]);
      advanceFromCompleting();
    },
    // On error: show retry UI — do NOT auto-advance, the session wasn't recorded
    onError: () => {
      if (completeTimeoutRef.current) {
        clearTimeout(completeTimeoutRef.current);
        completeTimeoutRef.current = null;
      }
      setSaveError(true);
    },
  });

  useEffect(() => {
    if (state !== "countdown") return;

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          setState("active");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [state]);

  useEffect(() => {
    // These sessions use their own engines and manage timing independently
    if (sessionId === "light-movement" || sessionId === "focus-block") return;
    if (state !== "active" || session.type === "instant") return;

    intervalRef.current = setInterval(() => {
      setElapsed(prev => {
        const next = prev + 1;
        if (next >= session.durationSeconds) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          // Beep to signal timer completion (timer-type sessions only)
          if (session.type === "timer") {
            playSessionCompleteBeep();
          }
          return session.durationSeconds;
        }
        return next;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [state, session.type, session.durationSeconds, sessionId]);

  useEffect(() => {
    if (sessionId === "light-movement" || sessionId === "focus-block") return;
    if (session.type !== "instant" && elapsed >= session.durationSeconds && state === "active") {
      handleComplete();
    }
  }, [elapsed, session.durationSeconds, state, sessionId]);

  const handleComplete = useCallback(() => {
    if (state !== "active") return;
    setState("completing");
    setSaveError(false);
    // Network-hang guard: if the mutation takes >12s, surface the retry UI instead of auto-advancing
    completeTimeoutRef.current = setTimeout(() => {
      setSaveError(true);
      completeTimeoutRef.current = null;
    }, 12000);
    completeMutation.mutate();
  }, [state, completeMutation]);

  const handleInstantDone = () => {
    handleComplete();
  };

  /* Cleanup failsafe timeout on unmount */
  useEffect(() => () => {
    if (completeTimeoutRef.current) clearTimeout(completeTimeoutRef.current);
  }, []);

  if (!session) {
    setLocation("/");
    return null;
  }

  // Light Movement uses the video-guided engine instead of the generic session page
  if (sessionId === "light-movement" && player?.id) {
    const handleLightMovementComplete = () => {
      queryClient.invalidateQueries({ queryKey: ["home"] });
      sessionStorage.setItem("ascend_just_completed_day", "2");
      setLocation("/");
    };

    return (
      <LightMovementEngine
        playerId={player.id}
        onComplete={handleLightMovementComplete}
        onCancel={() => setLocation("/")}
      />
    );
  }

  // Light Cardio Session uses the video-guided cardio engine
  if (sessionId === "focus-block" && player?.id) {
    const handleCardioComplete = () => {
      queryClient.invalidateQueries({ queryKey: ["home"] });
      sessionStorage.setItem("ascend_just_completed_day", "4");
      setLocation("/");
    };

    return (
      <CardioSessionEngine
        playerId={player.id}
        onComplete={handleCardioComplete}
        onCancel={() => setLocation("/")}
      />
    );
  }

  const accentColor = STAT_COLORS[session.stat] || "#3b82f6";
  const progress = session.durationSeconds > 0 ? Math.min(elapsed / session.durationSeconds, 1) : 0;
  const Icon = session.icon;

  return (
    <div
      data-testid="guided-session-page"
      className="fixed inset-0 z-40 flex flex-col"
      style={{ backgroundColor: backgroundTheme.colors.background }}
    >
      {/* Calm breathing ambient video background */}
      {sessionId === "calm-breathing" && state === "active" && (
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <video
            src="/videos/calm-breathing.mp4"
            className="w-full h-full object-cover"
            autoPlay
            playsInline
            muted
            loop
            preload="auto"
            style={{ opacity: 0.25 }}
          />
          <div
            className="absolute inset-0"
            style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.3) 50%, rgba(0,0,0,0.7) 100%)" }}
          />
        </div>
      )}
      <style>{`
        @keyframes gsGlowPulse {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.6; }
        }
        @keyframes gsFadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes gsDoneGlow {
          0% { opacity: 0; transform: scale(0.95); }
          50% { opacity: 1; transform: scale(1.02); }
          100% { opacity: 1; transform: scale(1); }
        }
      `}</style>

      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <Icon size={16} style={{ color: `${accentColor}99` }} />
          <span className="text-xs font-display tracking-wide" style={{ color: "rgba(255,255,255,0.6)" }}>
            {session.title}
          </span>
        </div>
        <button
          data-testid="button-close-session"
          onClick={() => setLocation("/")}
          className="p-2 rounded-lg transition-all active:scale-95"
          style={{ color: "rgba(255,255,255,0.4)" }}
        >
          <X size={18} />
        </button>
      </div>

      {session.type !== "instant" && (
        <div className="px-4">
          <div className="w-full h-1 rounded-full overflow-hidden" style={{ backgroundColor: "rgba(255,255,255,0.06)" }}>
            <div
              data-testid="session-progress-bar"
              className="h-full rounded-full transition-all"
              style={{
                width: `${progress * 100}%`,
                backgroundColor: `${accentColor}60`,
                transitionDuration: "1s",
                transitionTimingFunction: "linear",
              }}
            />
          </div>
        </div>
      )}

      <div className="flex-1 flex items-center justify-center" style={{ animation: "gsFadeIn 0.5s ease-out" }}>
        {state === "countdown" && (
          <div className="flex flex-col items-center gap-6">
            <p className="text-sm tracking-wide" style={{ color: "rgba(255,255,255,0.5)" }}>
              Get comfortable. Starting in...
            </p>
            <p
              data-testid="countdown-number"
              className="text-6xl font-display font-light"
              style={{
                color: `${accentColor}bb`,
                animation: "gsFadeIn 0.3s ease-out",
              }}
              key={countdown}
            >
              {countdown}
            </p>
          </div>
        )}
        {state === "active" && session.type === "breathing" && (
          <BreathingSession accentColor={accentColor} />
        )}
        {state === "active" && session.type === "prompts" && (
          <PromptSession elapsed={elapsed} accentColor={accentColor} />
        )}
        {state === "active" && session.type === "instant" && (
          <InstantSession sessionId={session.id} accentColor={accentColor} onDone={handleInstantDone} />
        )}
        {state === "active" && session.type === "timer" && (
          <TimerSession sessionId={session.id} elapsed={elapsed} total={session.durationSeconds} accentColor={accentColor} />
        )}
        {state === "completing" && (
          <div className="flex flex-col items-center gap-4" style={{ animation: "gsDoneGlow 0.5s ease-out" }}>
            <div
              className="w-16 h-16 rounded-full"
              style={{
                background: `radial-gradient(circle, ${accentColor}20 0%, transparent 70%)`,
                animation: saveError ? "none" : "gsGlowPulse 2s ease-in-out infinite",
              }}
            />
            {saveError ? (
              <>
                <p className="text-sm text-center" style={{ color: "rgba(255,100,100,0.8)" }}>
                  Couldn't save your session. Check your connection.
                </p>
                <button
                  data-testid="button-retry-save"
                  onClick={() => { setSaveError(false); completeMutation.mutate(); }}
                  className="px-6 py-2.5 rounded-xl text-sm font-medium transition-all active:scale-95"
                  style={{ backgroundColor: `${accentColor}20`, border: `1px solid ${accentColor}40`, color: accentColor }}
                >
                  Retry
                </button>
              </>
            ) : (
              <p className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
                Saving your progress...
              </p>
            )}
          </div>
        )}
        {state === "done" && (
          <div className="flex flex-col items-center gap-6 px-8 text-center" style={{ animation: "gsFadeIn 0.4s ease-out" }}>
            <div
              className="w-16 h-16 rounded-full"
              style={{ background: `radial-gradient(circle, ${accentColor}20 0%, transparent 70%)` }}
            />
            <p className="text-lg font-display font-medium" style={{ color: "rgba(255,255,255,0.9)" }}>
              Step complete.
            </p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
              {t("You showed up. Momentum begins.")}
            </p>
            <button
              data-testid="button-return-home"
              onClick={() => setLocation("/")}
              className="mt-4 px-8 py-3 rounded-xl font-display text-sm uppercase tracking-[0.12em] transition-all active:scale-[0.97]"
              style={{
                backgroundColor: `${accentColor}12`,
                border: `1px solid ${accentColor}20`,
                color: `${accentColor}cc`,
              }}
            >
              Return Home
            </button>
          </div>
        )}
      </div>

      {state === "active" && session.type !== "instant" && (
        <div className="px-4 pb-6 text-center">
          <p className="text-[10px] tracking-wide" style={{ color: "rgba(255,255,255,0.25)" }}>
            {Math.ceil((session.durationSeconds - elapsed) / 60)} min remaining
          </p>
        </div>
      )}

      <Day5ExpansionOverlay
        visible={showDay5Expansion}
        onComplete={() => {
          setShowDay5Expansion(false);
          setLocation("/");
        }}
        onSkip={() => {
          setShowDay5Expansion(false);
          setShowDayClose(true);
        }}
        onSessionComplete={() => {
          if (player?.id) {
            apiRequest("POST", `/api/player/${player.id}/complete-guided-session`, {
              sessionId: "day5-expansion",
              stat: "vitality",
              durationMinutes: 1,
            }).then(() => {
              queryClient.invalidateQueries({ queryKey: ["home"] });
              queryClient.invalidateQueries({ queryKey: ["/api/player"] });
              const count = parseInt(localStorage.getItem("ascend_multi_action_days") || "0", 10);
              localStorage.setItem("ascend_multi_action_days", String(count + 1));
            });
          }
        }}
      />

      <DayCloseOverlay
        visible={showDayClose}
        onboardingDay={homeData?.onboardingDay ?? 1}
        onClose={() => {
          setShowDayClose(false);
          setLocation("/");
        }}
      />
    </div>
  );
}
